clear all
close all;

%% Measurement Emulation 



I_sig=1;
I0_off=20;
Ids_gain=10;
I_var=I_sig^2;

V_sig=0.01;
V0_off=0.2;
Vds_gain=1;
V_var=V_sig^2;

Qi = [5,0,0;
     0,5,0;
     0,0,10];
 
Qv = [1,0,0;
     0,1,0;
     0,0,10];
 
 

%% Voltage Signal
fs=1000;
delta_t=1/fs;
freq=20;
omega=2*pi*freq;
omega_k=omega/fs;
gain=1;

%% Kalman Filter intial factors and Matrices

%Prediction Matrices & factors
A_c=[0,1,0;
    -omega^2,0,0;
    0,0,0];

X_kal =[0;0;0];

P =[0,0,0;
    0,0,0;
    0,0,0];

A =[cos(omega_k),sin(omega_k)/omega, 0;
    -sin(omega_k)*omega,cos(omega_k),0;
    0,0,1];
B = [0;0;0];

Bv = [1;0;0];
U = 0;

% Correction Matrices

H = [1,0,1];
Rv = V_var ;
Ri = I_var ;

c_system=ss(A_c,B,H,0);
d_system=c2d(c_system,delta_t);
Ad=d_system.A;
