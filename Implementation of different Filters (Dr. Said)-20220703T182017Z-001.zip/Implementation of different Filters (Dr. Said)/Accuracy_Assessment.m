clear all
close all;

%% Accuracy Assessment: RMSE Calculation
string='_700hz'
load(strcat('Results_constant_noise', string))

% Original Signals
t=out.tout; 
Vds_org=out.Vds_org.data;
Id_org=out.Id_org.data; 
Rds_org=out.Rds_org.data;
Tj_org=out.Tj_original.data;

% Voltage Estimates
Vds_KF_Single=out.Vds_KF_Single.data; 
Vds_KF_Seperate=out.Vds_KF_Seperate.data; 
Vds_RGN=out.Vds_RGN.data;

% Current Estimates 
Id_KF_Single=out.Id_KF_Single.data; 
Id_KF_Seperate=out.Id_KF_Seperate.data; 
Id_RGN=out.Id_RGN.data;

% Resistance Estimates 
Rds_KF_Single=out.Rds_KF_Single.data; 
Rds_KF_Seperate=out.Rds_KF_Seperate.data; 
Rds_RGN=out.Rds_RGN.data;

% Temperature Estimates 
Tj_KF_Single=out.Tj_KF_Single.data; 
Tj_KF_Seperate=out.Tj_KF_Seperate.data;
Tj_RGN=out.Tj_RGN.data;

%% RMSE Calculation 

% Voltage RMSE
RMSE_Vds_KF_Single=RMSE(Vds_org,Vds_KF_Single);
RMSE_Vds_KF_Seperate=RMSE(Vds_org,Vds_KF_Seperate);
RMSE_Vds_RGN=RMSE(Vds_org,Vds_RGN);

% Current RMSE
RMSE_Id_KF_Single=RMSE(Id_org,Id_KF_Single);
RMSE_Id_KF_Seperate=RMSE(Id_org,Id_KF_Seperate);
RMSE_Id_RGN=RMSE(Id_org,Id_RGN);

% Resistance RMSE
RMSE_Rds_KF_Single=RMSE(Rds_org,Rds_KF_Single);
RMSE_Rds_KF_Seperate=RMSE(Rds_org,Rds_KF_Seperate);
RMSE_Rds_RGN=RMSE(Rds_org,Rds_RGN);

% Voltage RMSE
RMSE_Tj_KF_Single=RMSE(Tj_org,Tj_KF_Single);
RMSE_Tj_KF_Seperate=RMSE(Tj_org,Tj_KF_Seperate);
RMSE_Tj_RGN=RMSE(Tj_org,Tj_RGN);



%% Plotting RMSE 

% Voltage RMSE
figure(1);
plot(t,RMSE_Vds_KF_Single,'blue');
hold on 
plot(t,RMSE_Vds_KF_Seperate, 'black');
plot(t,RMSE_Vds_RGN,'green');
legend({'Single KF Estimate','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$V_{ds}[V]$','FontSize',14, 'Interpreter','latex');
title('Drain-Source Voltage RMSE','FontSize',18);

% Current RMSE
figure(2);
plot(t,RMSE_Id_KF_Single,'blue');
hold on 
plot(t,RMSE_Id_KF_Seperate, 'black');
plot(t,RMSE_Id_RGN,'green');
legend({'Single KF Estimate','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$I_d[A]$','FontSize',14, 'Interpreter','latex');
title('Drain Current RMSE','FontSize',18);

% Resistance RMSE
figure(3);
plot(t,RMSE_Rds_KF_Single,'blue');
hold on 
plot(t,RMSE_Rds_KF_Seperate, 'black');
plot(t,RMSE_Rds_RGN,'green');
legend({'Single KF Estimate','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$R_{dson}[m\Omega]$','FontSize',14, 'Interpreter','latex');
title('On-State Resistance RMSE','FontSize',18);


% Junction Temperature RMSE
figure(4);
plot(t,RMSE_Tj_KF_Single,'blue');
hold on 
plot(t,RMSE_Tj_KF_Seperate, 'black');
plot(t,RMSE_Tj_RGN,'green');
legend({'Single KF Estimate','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$T_j[C^{\circ}]$','FontSize',14, 'Interpreter','latex');
title('Junction Temperature RMSE','FontSize',18);
saveas(figure(4),strcat('Robustness/temperature_RMSE',string,'.eps'))

%% Plotting Estimates

% Voltage Estimate 
figure(5);
plot(t,Vds_KF_Single,'blue');
hold on 
plot(t,Vds_org,'red');
plot(t,Vds_KF_Seperate, 'black');
plot(t,Vds_RGN,'green');
legend({'Single KF Estimate','True $V_{ds}$','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$V_{ds}[V]$','FontSize',14, 'Interpreter','latex');
title('Drain-Source Voltage Estimation','FontSize',18);

% Current Estimate
figure(6);
plot(t,Id_KF_Single,'blue');
hold on 
plot(t,Id_org,'red');
plot(t,Id_KF_Seperate, 'black');
plot(t,Id_RGN,'green');
legend({'Single KF Estimate','True $I_d$','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$I_d[A]$','FontSize',14, 'Interpreter','latex');
title('Drain Current Estimation','FontSize',18);

% Resistance Estimate
figure(7);
plot(t,Rds_KF_Single,'blue');
hold on 
plot(t,Rds_org, 'red');
plot(t,Rds_KF_Seperate, 'black');
plot(t,Rds_RGN,'green');
legend({'Single KF Estimate','True Signal','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex', 'Location','best');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$R_{dson}[m\Omega]$','FontSize',14, 'Interpreter','latex');
title('On-State Resistance Estimation','FontSize',18);
saveas(figure(7),strcat('Robustness/Resistance_Estimate',string,'.eps'))

% Junction Temperature Estimate
figure(8);
plot(t,Tj_KF_Single,'blue');
hold on 
plot(t,Tj_org, 'red');
plot(t,Tj_KF_Seperate, 'black');
plot(t,Tj_RGN,'green');
legend({'Single KF Estimate','True Signal','Seperate KF Estimate','RGN Estimate'},'FontSize',14,'Interpreter','latex');
grid on ; 
xlabel('t[$\mu s$]','FontSize',14, 'Interpreter','latex');
ylabel('$T_j[C^{\circ}]$','FontSize',14, 'Interpreter','latex');
title('Junction Temperature Estimation','FontSize',18);
saveas(figure(8),strcat('Robustness/temperature_Estimate',string,'.eps'))

