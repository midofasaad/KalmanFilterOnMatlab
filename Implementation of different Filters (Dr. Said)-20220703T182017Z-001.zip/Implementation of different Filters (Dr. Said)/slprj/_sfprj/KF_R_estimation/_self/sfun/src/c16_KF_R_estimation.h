#ifndef __c16_KF_R_estimation_h__
#define __c16_KF_R_estimation_h__
#ifdef __has_include
#if __has_include(<time.h>)
#include <time.h>
#else
#error Cannot find header file <time.h> for imported type time_t.\
 Supply the missing header file or turn on Simulation Target -> Generate typedefs\
 for imported bus and enumeration types.
#endif

#else
#include <time.h>
#endif

/* Forward Declarations */
#ifndef typedef_c16_sxaDueAh1f53T9ESYg9Uc4E
#define typedef_c16_sxaDueAh1f53T9ESYg9Uc4E

typedef struct c16_tag_sxaDueAh1f53T9ESYg9Uc4E c16_sxaDueAh1f53T9ESYg9Uc4E;

#endif                                 /* typedef_c16_sxaDueAh1f53T9ESYg9Uc4E */

#ifndef typedef_c16_cell_0
#define typedef_c16_cell_0

typedef struct c16_tag_n3SDPft8LycMqfcEsfJVBB c16_cell_0;

#endif                                 /* typedef_c16_cell_0 */

#ifndef typedef_c16_s_wvzWMLKjXp7EJVnnMvwbTC
#define typedef_c16_s_wvzWMLKjXp7EJVnnMvwbTC

typedef struct c16_tag_wvzWMLKjXp7EJVnnMvwbTC c16_s_wvzWMLKjXp7EJVnnMvwbTC;

#endif                                 /* typedef_c16_s_wvzWMLKjXp7EJVnnMvwbTC */

/* Type Definitions */
#ifndef struct_c16_tag_sxaDueAh1f53T9ESYg9Uc4E
#define struct_c16_tag_sxaDueAh1f53T9ESYg9Uc4E

struct c16_tag_sxaDueAh1f53T9ESYg9Uc4E
{
  real_T tm_min;
  real_T tm_sec;
  real_T tm_hour;
  real_T tm_mday;
  real_T tm_mon;
  real_T tm_year;
};

#endif                                 /* struct_c16_tag_sxaDueAh1f53T9ESYg9Uc4E */

#ifndef typedef_c16_sxaDueAh1f53T9ESYg9Uc4E
#define typedef_c16_sxaDueAh1f53T9ESYg9Uc4E

typedef struct c16_tag_sxaDueAh1f53T9ESYg9Uc4E c16_sxaDueAh1f53T9ESYg9Uc4E;

#endif                                 /* typedef_c16_sxaDueAh1f53T9ESYg9Uc4E */

#ifndef struct_c16_tag_n3SDPft8LycMqfcEsfJVBB
#define struct_c16_tag_n3SDPft8LycMqfcEsfJVBB

struct c16_tag_n3SDPft8LycMqfcEsfJVBB
{
  char_T f1[6];
  char_T f2[6];
  char_T f3[7];
  char_T f4[7];
  char_T f5[6];
  char_T f6[7];
};

#endif                                 /* struct_c16_tag_n3SDPft8LycMqfcEsfJVBB */

#ifndef typedef_c16_cell_0
#define typedef_c16_cell_0

typedef struct c16_tag_n3SDPft8LycMqfcEsfJVBB c16_cell_0;

#endif                                 /* typedef_c16_cell_0 */

#ifndef struct_c16_tag_wvzWMLKjXp7EJVnnMvwbTC
#define struct_c16_tag_wvzWMLKjXp7EJVnnMvwbTC

struct c16_tag_wvzWMLKjXp7EJVnnMvwbTC
{
  c16_cell_0 _data;
};

#endif                                 /* struct_c16_tag_wvzWMLKjXp7EJVnnMvwbTC */

#ifndef typedef_c16_s_wvzWMLKjXp7EJVnnMvwbTC
#define typedef_c16_s_wvzWMLKjXp7EJVnnMvwbTC

typedef struct c16_tag_wvzWMLKjXp7EJVnnMvwbTC c16_s_wvzWMLKjXp7EJVnnMvwbTC;

#endif                                 /* typedef_c16_s_wvzWMLKjXp7EJVnnMvwbTC */

#ifndef typedef_SFc16_KF_R_estimationInstanceStruct
#define typedef_SFc16_KF_R_estimationInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c16_JITTransitionAnimation[1];
  int32_T c16_sfEvent;
  boolean_T c16_doneDoubleBufferReInit;
  uint8_T c16_is_active_c16_KF_R_estimation;
  uint8_T c16_JITStateAnimation[1];
  int32_T c16_IsDebuggerActive;
  int32_T c16_IsSequenceViewerPresent;
  int32_T c16_SequenceViewerOptimization;
  int32_T c16_IsHeatMapPresent;
  void *c16_RuntimeVar;
  uint32_T c16_seed;
  boolean_T c16_seed_not_empty;
  uint32_T c16_method;
  boolean_T c16_method_not_empty;
  uint32_T c16_state[625];
  boolean_T c16_state_not_empty;
  uint32_T c16_b_state[2];
  boolean_T c16_b_state_not_empty;
  uint32_T c16_c_state;
  boolean_T c16_c_state_not_empty;
  uint32_T c16_b_method;
  boolean_T c16_b_method_not_empty;
  uint32_T c16_d_state[2];
  boolean_T c16_d_state_not_empty;
  uint32_T c16_mlFcnLineNumber;
  void *c16_fcnDataPtrs[4];
  char_T *c16_dataNames[4];
  uint32_T c16_numFcnVars;
  uint32_T c16_ssIds[4];
  uint32_T c16_statuses[4];
  void *c16_outMexFcns[4];
  void *c16_inMexFcns[4];
  CovrtStateflowInstance *c16_covrtInstance;
  void *c16_fEmlrtCtx;
  real_T *c16_v_sig;
  real_T *c16_v_noise;
  real_T *c16_k;
  real_T *c16_b_k;
} SFc16_KF_R_estimationInstanceStruct;

#endif                                 /* typedef_SFc16_KF_R_estimationInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c16_KF_R_estimation_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c16_KF_R_estimation_get_check_sum(mxArray *plhs[]);
extern void c16_KF_R_estimation_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
