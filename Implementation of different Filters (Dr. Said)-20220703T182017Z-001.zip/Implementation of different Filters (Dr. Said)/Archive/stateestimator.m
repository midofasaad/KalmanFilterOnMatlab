clear all
close all


a0=0.5;
b0=1.2;
Fs=2000;
Ts=1/Fs;
H=1;
F0=20;
w=2*pi*F0;

% state space model of a sine wave

A=[0   1   0
   -w^2 0   0
   0   0   0];

B=[1 0 0]';
C=[w 0 1];

csys=ss(A,B,C,0);
dsys=c2d(csys,Ts,'zoh');
Ad=dsys.a;
Bd=dsys.b;
Cd=dsys.c;