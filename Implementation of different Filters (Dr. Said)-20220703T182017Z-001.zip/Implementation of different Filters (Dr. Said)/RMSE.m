function [estimate_RMSE] = RMSE(estimate,original_Signal)
% Calculate the RMSE 
estimate_RMSE= [];
for i=1:length(estimate)
    y=estimate(1:i);
    error=(y - original_Signal(1:i)).^2 ;   % Errors
    mean_error= mean(error);   % Mean Squared Error
    RMSE = sqrt(mean_error);  % Root Mean Squared Error
    estimate_RMSE=[estimate_RMSE,RMSE];

end